Introduction
-----------

Himalaya is a simple, clean and responsive layout theme for frontend. Its very 
light weight and easy to use. Which provide two column layout one is sidebar 
and second is content.

  FEATURES:-
  --------
  
   - Responsive, Mobile-Friendly Theme
   - HTML5 and CSS3
   - Mobile support (Tablet, Android, iPhone, etc)
   - Responsive layout
   - 2-columns layout
   - Total 9 regions
   - Minimal design and nice typography
   - Supported standard theme features: user picture in comment and posts etc

Requirements
------------

No special requirements

Installation
------------
* Clone theme into sites/all/themes from this link
git clone --branch 7.x-1.x http://git.drupal.org/sandbox/sumitkumar/2467223.git
himalaya
  Its create himalaya folder in sites/all/themes

* https://www.drupal.org/node/2470681 for further information.

* Enable the theme Aministration Menu.
  Aministration Menu >> Appearance 
  Chosse theme

Configuration
-------------

Find the configuration of theme here:
<strong>admin/appearance/settings/himalaya</strong>
