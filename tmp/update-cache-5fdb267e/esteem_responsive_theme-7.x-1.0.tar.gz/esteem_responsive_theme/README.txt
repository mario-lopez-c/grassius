About Theme
------------------------------
Esteem theme is a very modern and professional Drupal theme that is perfect 
for all sorts of corporate and small business websites.The theme is not 
dependent on any core theme. Its very light weight with modern look and feel. 

Drupal compatibility:
------------------------------
This theme is compatible with Drupal 7.x

Required Modules:
------------------------------
https://www.drupal.org/project/nivo_slider
https://www.drupal.org/project/fontawesome

Browser compatibility
------------------------------
IE 8+ and all modern browsers
