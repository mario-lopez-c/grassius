/* --------------------------------------------- 

* Filename:     custom.js
* Version:      1.0.0 (2015-03-21)
* Website:      http://www.zymphonies.com
                http://www.freebiezz.com
* Description:  System JS
* Author:       Zymphonies Team
                info@zymphonies.com
                
-----------------------------------------------*/

jQuery(function($){
  $(document).ready(function() {
    // initialise Superfish
    $('#main-menu ul').superfish({
        animation: {height:'show'}
    });
  });
});
