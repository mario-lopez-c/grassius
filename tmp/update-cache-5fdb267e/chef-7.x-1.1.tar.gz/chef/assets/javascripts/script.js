(function ($) {
  // code here
})(jQuery);
